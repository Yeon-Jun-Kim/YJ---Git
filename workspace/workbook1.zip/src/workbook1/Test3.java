package workbook1;
public class Test3 {
public static void main(String[] args) {
char ch = 'z';
boolean b =  (65<=ch && ch<=90 || 97<=ch && ch<=122);
System.out.println(b);
}
}