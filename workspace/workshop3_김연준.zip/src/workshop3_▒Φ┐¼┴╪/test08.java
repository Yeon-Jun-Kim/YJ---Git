package workshop3_김연준;
import java.util.Arrays;


public class test08 {
	public static void main(String[] args) {
		int [] score= {99,34,67,22,11,9};
		Arrays.sort(score);
		System.out.println("최대값 :" + score[5] + "최솟값" + score[0]);

	}
	
}
