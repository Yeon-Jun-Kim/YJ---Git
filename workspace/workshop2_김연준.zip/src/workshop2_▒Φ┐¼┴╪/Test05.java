package workshop2_김연준;
public class Test05 {
public static void main(String[] args) {
	
	int i = (int) (Math.random() * (6-1+1)) + 1;
	System.out.println(i);
}
}