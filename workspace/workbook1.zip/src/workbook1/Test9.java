package workbook1;

import java.util.Scanner;

public class Test9 {
public static void main(String[] args) {
 // Scanner 이용하여 값을 입력 받는 코드 구현
 Scanner scan = new Scanner(System.in);
 System.out.println("정수 입력하세요");
 int a = scan.nextInt();
 System.out.println("정수 입력하세요");
 int b = scan.nextInt();
 int c = a+b;
 System.out.println("정수" + a + "정수" + b + "의 합은" + c );
 
 
	
}
}


