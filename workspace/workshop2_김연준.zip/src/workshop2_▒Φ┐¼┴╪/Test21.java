package workshop2_김연준;

import java.util.Scanner;

public class Test21 {
public static void main(String[] args) {
	int j= 1;
	for(int i = 0; i<10; i++) {
		for(int k = 0; k<10; k++)
		{
			System.out.print(j + " ");
			j++;
		}
		System.out.println();
	}

}}