package workshop3_김연준;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class test10 {
	public static void main(String[] args) {
		int sum = 0;
		Scanner scan = new Scanner(System.in);
		String a = scan.nextLine();
		System.out.println(a);	
		Random r = new Random();
	}
		
		
		
	
	
}
