package workbook1;
public class Test6 {
public static void main(String[] args) {
int i = 5;
String result = (i%2==0)? "짝수":"홀수";
System.out.println("숫자"+ i + "는 홀수입니다." );
}
}
