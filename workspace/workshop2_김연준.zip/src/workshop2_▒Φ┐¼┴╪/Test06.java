package workshop2_김연준;

import com.sun.glass.ui.Pixels.Format;

public class Test06 {
public static void main(String[] args) {
	for(int i = 1; i<=6; i++)
	{
		for(int j = 1; j<=6; j++)
		{
			for(int k = 1; k<=6; k++)
			{
				if(i*j*k % 3 == 0)
				{
					System.out.println(String.format("%d * %d *%d = %d"
							,i,j,k,i*j*k));
					
				}
			}
		}
	}
	
	
}
}