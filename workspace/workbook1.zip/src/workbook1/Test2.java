package workbook1;
public class Test2 {
public static void main(String[] args) {
int num = 456;
int result = 100 * (num / 100);
System.out.println(result);
}
}
